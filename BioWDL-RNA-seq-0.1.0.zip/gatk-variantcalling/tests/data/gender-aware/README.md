`human_female_male` sample from [biowdl-test-data](
https://github.com/biowdl/biowdl-test-data).
