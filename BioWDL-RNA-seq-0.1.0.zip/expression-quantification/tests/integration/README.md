# Integration tests
This folder contains the tests that ensure that the workflow is 
working on a basic level. Small files are used so the workflow finishes
quickly. These tests allow for quick testing if the workflow functions
during development.
