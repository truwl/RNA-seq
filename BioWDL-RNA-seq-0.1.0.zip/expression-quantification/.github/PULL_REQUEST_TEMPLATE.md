### Checklist
- [ ] Pull request details were added to CHANGELOG.md.
- [ ] Documentation was updated (if required).
- [ ] Workflow `parameter_meta` was added/updated (if required).
