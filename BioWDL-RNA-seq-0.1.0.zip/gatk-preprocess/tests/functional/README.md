# Functional tests

This folder contains the tests that are run with big files on our research cluster.
These tests ensure that the pipeline will run in a production environment with
big data.
