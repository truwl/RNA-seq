# Integration tests

This folder contains the tests that ensure that the pipeline is 
working on a basic level. Small files are used so the pipeline finishes
quickly. These tests allow for quick testing if the pipeline functions
during development.
